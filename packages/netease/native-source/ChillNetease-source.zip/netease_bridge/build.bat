@echo off
setlocal EnableDelayedExpansion

:: ChillNetease.dll Build Script
:: This script clones go-musicfox, copies netease_bridge, and builds the DLL

:: Go 和 C 编译器由 setup_toolchain 确保在 PATH 中
where go >nul 2>&1 || ( echo ERROR: Go not in PATH! & exit /b 1 )

:: 优先使用已设置的 CC 环境变量，否则自动找 clang → gcc
if not defined CC (
    where clang >nul 2>&1 && set CC=clang -fuse-ld=lld
)
if not defined CC (
    where gcc >nul 2>&1 && set CC=gcc
)
if defined CC echo Using C compiler: %CC%
set CGO_ENABLED=1
set GOOS=windows
set GOARCH=amd64

:: 配置
set "SCRIPT_DIR=%~dp0"
:: 项目根目录 = Chill 根目录（从 NativePlugins\netease_bridge\ 上两级）
set "PROJECT_ROOT=%SCRIPT_DIR%..\.."
set "BUILD_DIR=%PROJECT_ROOT%\build\netease_bridge"
set "GOMUSICFOX_URL=https://github.com/go-musicfox/go-musicfox.git"
set "GOMUSICFOX_BRANCH=master"
set "OUTPUT_DIR=%PROJECT_ROOT%\bin\native\x64"

echo ===========================================
echo ChillNetease.dll Build Script
echo ===========================================
echo.

:: 检查 Go 版本
echo [1/5] Checking Go version...
go version
if errorlevel 1 (
    echo ERROR: Go not found! Please install Go from https://go.dev/
    exit /b 1
)

:: 检查 C 编译器版本（支持 clang 或 gcc）
echo.
echo [2/5] Checking C compiler (%CC%)...
%CC% --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: C compiler not found! Set CC=clang or install MinGW-w64
    exit /b 1
)
%CC% --version | findstr /i "gcc clang" >nul 2>&1

:: 检查 Git
echo.
echo [3/5] Checking Git...
git --version | findstr "git"
if errorlevel 1 (
    echo ERROR: Git not found! Please install Git
    exit /b 1
)

:: 准备构建目录
echo.
echo [4/5] Preparing build directory...
if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"
cd /d "%BUILD_DIR%"

:: 克隆或更新 go-musicfox
echo.
if exist "go-musicfox\.git" (
    echo Updating go-musicfox repository...
    cd go-musicfox
    git pull --ff-only
    if errorlevel 1 (
        echo WARNING: git pull failed, continuing with existing code...
    )
    cd ..
) else (
    echo Cloning go-musicfox repository...
    if exist "go-musicfox" rmdir /s /q "go-musicfox"
    git clone --depth 1 --branch %GOMUSICFOX_BRANCH% %GOMUSICFOX_URL% go-musicfox
    if errorlevel 1 (
        echo ERROR: Failed to clone go-musicfox!
        exit /b 1
    )
)

:: 复制我们的 netease_bridge 代码
echo.
echo Copying netease_bridge source code...
if not exist "go-musicfox\netease_bridge" mkdir "go-musicfox\netease_bridge"
copy /Y "%SCRIPT_DIR%*.go" "go-musicfox\netease_bridge\" >nul
copy /Y "%SCRIPT_DIR%.gitignore" "go-musicfox\netease_bridge\" 2>nul

:: 进入 go-musicfox 目录
cd go-musicfox

:: 添加 netease_bridge 需要但 go-musicfox 未包含的依赖到 vendor
echo.
echo Adding extra dependencies to vendor...
go get github.com/telanflow/cookiejar@latest >nul 2>&1
go mod vendor >nul 2>&1

:: 修复上游库的假 NMTID cookie（会被网易云服务器拒绝）
powershell -Command "$f='vendor\github.com\go-musicfox\netease-music\util\common.go'; $c=[IO.File]::ReadAllText($f,[Text.Encoding]::UTF8); $c=$c.Replace('some_random_id_from_strategy','nmtid_'+[guid]::NewGuid().ToString('N').Substring(0,16)); [IO.File]::WriteAllText($f,$c,[Text.Encoding]::UTF8)" >nul 2>&1

:: 构建 DLL
echo.
echo [5/5] Building DLL...
go build -buildmode=c-shared -o netease_bridge\ChillNetease.dll -ldflags "-s -w" ./netease_bridge

if errorlevel 1 (
    echo.
    echo ERROR: Build failed!
    exit /b 1
)

echo.
echo ===========================================
echo Build successful!
echo ===========================================

:: 复制输出文件
echo.
echo Copying output files...
if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"

copy /Y "netease_bridge\ChillNetease.dll" "%OUTPUT_DIR%\"
copy /Y "netease_bridge\ChillNetease.h" "%OUTPUT_DIR%\" 2>nul

:: 同时复制到 netease_bridge 目录（方便调试）
copy /Y "netease_bridge\ChillNetease.dll" "%SCRIPT_DIR%\"
copy /Y "netease_bridge\ChillNetease.h" "%SCRIPT_DIR%\" 2>nul

echo.
echo Output files:
echo   - %OUTPUT_DIR%\ChillNetease.dll
echo   - %SCRIPT_DIR%ChillNetease.dll (debug copy)
echo.

:: 清理构建目录 (可选，取消注释以启用)
:: echo Cleaning up build directory...
:: cd /d "%PROJECT_ROOT%"
:: rmdir /s /q "%BUILD_DIR%"

echo Done!
if "%1"=="" pause
