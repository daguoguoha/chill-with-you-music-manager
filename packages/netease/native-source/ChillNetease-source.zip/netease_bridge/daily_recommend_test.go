package main

import "testing"

func TestDailyRecommendations(t *testing.T) {
	songs, err := parseDailyRecommendations([]byte(`{"code":200,"data":{"dailySongs":[{"id":1,"name":"Test","dt":180001,"ar":[{"name":"Artist"}],"al":{"id":2,"name":"Album"}},{"id":1},{"id":0}]}}`))
	if err != nil || len(songs) != 1 || songs[0].ID != 1 || songs[0].Duration != 180.001 || songs[0].Artists[0] != "Artist" || songs[0].AlbumID != 2 {
		t.Fatalf("Unexpected daily songs result: %v", err)
	}
	for _, bad := range []string{`invalid`, `{"code":301}`, `{"code":200,"data":{"dailySongs":[]}}`, `{"code":200,"data":{"dailySongs":[{"id":0}]}}`} {
		if _, err := parseDailyRecommendations([]byte(bad)); err == nil {
			t.Fatal("Accepted invalid response")
		}
	}
}
