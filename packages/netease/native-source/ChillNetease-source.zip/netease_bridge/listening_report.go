package main

/*
#include <stdlib.h>
*/
import "C"

import (
	"encoding/json"
	"io"
	"net/url"
	"strconv"
	"time"

	"github.com/go-musicfox/netease-music/util"
)

// NeteaseReportPlayback uses only the bridge's existing authenticated cookie jar.
// kind: 0 actual start, 1 natural end, 2 track change, 3 game shutdown.
// No retry is made: an ambiguous timeout must never duplicate listening time.
//
//export NeteaseReportPlayback
func NeteaseReportPlayback(id C.longlong, playlistID C.longlong, seconds C.longlong, kind C.int) C.int {
	if !initialized || currentUser == nil || currentUser.UserId <= 0 {
		return 401
	}
	logs, valid := listeningLogs(int64(id), int64(playlistID), int64(seconds), int(kind))
	if !valid {
		return 400
	}
	encoded, err := json.Marshal(logs)
	if err != nil {
		return 0
	}
	jar := util.GetGlobalCookieJar()
	csrf := util.GetCsrfToken(jar)
	data, err := util.ApiParamsEncode(map[string]interface{}{"logs": string(encoded), "csrf_token": csrf})
	if err != nil {
		return 0
	}
	request := util.NewRequest("https://clientlogusf.music.163.com/weapi/feedback/weblog?csrf_token="+url.QueryEscape(csrf), jar)
	request.Req.Client.Timeout = 8 * time.Second
	request.Datas = data
	response, err := request.SendPost()
	if err != nil {
		return 0
	}
	defer response.Body.Close()
	if response.StatusCode != 200 {
		return C.int(response.StatusCode)
	}
	var result struct {
		Code int `json:"code"`
	}
	if json.NewDecoder(io.LimitReader(response.Body, 65536)).Decode(&result) != nil {
		return 0
	}
	return C.int(result.Code)
}

// Matches the vendored netease-music ReportService payload without its unbounded request.
func listeningLogs(id, playlistID, seconds int64, kind int) ([]map[string]interface{}, bool) {
	if id <= 0 || playlistID < 0 || kind < 0 || kind > 3 || seconds < 0 || seconds > 86400 || (kind == 0 && seconds != 0) || (kind != 0 && seconds < 1) {
		return nil, false
	}
	entry := map[string]interface{}{"id": id, "type": "song", "content": "", "mainsite": "1", "mainsiteWeb": "1"}
	if playlistID > 0 {
		entry["content"] = "id=" + strconv.FormatInt(playlistID, 10)
		entry["sourceId"] = strconv.FormatInt(playlistID, 10)
	}
	action := "startplay"
	if kind != 0 {
		action = "play"
		entry["time"] = seconds
		entry["end"] = []string{"", "playend", "ui", "interrupt"}[kind]
		entry["wifi"] = 0
		entry["download"] = 0
		entry["source"] = "list"
	}
	return []map[string]interface{}{{"action": action, "json": entry}}, true
}
