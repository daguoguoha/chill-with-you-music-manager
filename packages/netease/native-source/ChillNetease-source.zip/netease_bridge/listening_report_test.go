package main

import "testing"

func TestListeningPayload(t *testing.T) {
	start, ok := listeningLogs(1, 2, 0, 0)
	if !ok || start[0]["action"] != "startplay" {
		t.Fatal("start")
	}
	for kind, reason := range map[int]string{1: "playend", 2: "ui", 3: "interrupt"} {
		logs, ok := listeningLogs(1, 2, 17, kind)
		if !ok || logs[0]["action"] != "play" {
			t.Fatal("end")
		}
		body := logs[0]["json"].(map[string]interface{})
		if body["time"] != int64(17) || body["sourceId"] != "2" || body["end"] != reason {
			t.Fatal("actual seconds/source/reason")
		}
	}
	for _, args := range [][4]int64{{0, 2, 1, 2}, {1, -1, 1, 2}, {1, 2, -1, 2}, {1, 2, 90000, 2}, {1, 2, 1, 0}, {1, 2, 0, 2}, {1, 2, 1, 4}} {
		if _, ok := listeningLogs(args[0], args[1], args[2], int(args[3])); ok {
			t.Fatal("invalid input accepted")
		}
	}
}
