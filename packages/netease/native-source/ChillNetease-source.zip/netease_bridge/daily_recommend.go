package main

/*
#include <stdlib.h>
*/
import "C"

import (
	"encoding/json"
	"fmt"
	"github.com/go-musicfox/netease-music/service"
)

// NeteaseGetDailyRecommendSongs reads the account's daily list, not personal FM.
//
//export NeteaseGetDailyRecommendSongs
func NeteaseGetDailyRecommendSongs() *C.char {
	if !initialized || currentUser == nil || currentUser.UserId <= 0 {
		lastError = "Daily recommendations require login"
		return nil
	}
	request := service.RecommendSongsService{}
	code, data := request.RecommendSongs()
	if code != 200 {
		lastError = fmt.Sprintf("Daily recommendations returned code: %.0f", code)
		return nil
	}
	songs, err := parseDailyRecommendations(data)
	if err != nil {
		lastError = err.Error()
		return nil
	}
	encoded, err := json.Marshal(songs)
	if err != nil {
		lastError = "Failed to encode daily recommendations"
		return nil
	}
	return C.CString(string(encoded))
}

func parseDailyRecommendations(data []byte) ([]SongInfo, error) {
	var response struct {
		Code int `json:"code"`
		Data struct {
			Songs []struct {
				ID       int64  `json:"id"`
				Name     string `json:"name"`
				Duration int64  `json:"dt"`
				Artists  []struct {
					Name string `json:"name"`
				} `json:"ar"`
				Album struct {
					ID   int64  `json:"id"`
					Name string `json:"name"`
					Pic  string `json:"picUrl"`
				} `json:"al"`
			} `json:"dailySongs"`
		} `json:"data"`
	}
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("Invalid daily recommendations response")
	}
	if response.Code != 200 {
		return nil, fmt.Errorf("Daily recommendations returned code: %d", response.Code)
	}
	if len(response.Data.Songs) > 2000 {
		return nil, fmt.Errorf("Daily recommendations response too large")
	}
	result := make([]SongInfo, 0, len(response.Data.Songs))
	seen := map[int64]bool{}
	for _, song := range response.Data.Songs {
		if song.ID <= 0 || seen[song.ID] {
			continue
		}
		seen[song.ID] = true
		artists := make([]string, 0, len(song.Artists))
		for _, artist := range song.Artists {
			if artist.Name != "" {
				artists = append(artists, artist.Name)
			}
		}
		result = append(result, SongInfo{ID: song.ID, Name: song.Name, Duration: float64(song.Duration) / 1000, Artists: artists, Album: song.Album.Name, AlbumID: song.Album.ID, CoverUrl: song.Album.Pic})
	}
	if len(result) == 0 {
		return nil, fmt.Errorf("No daily recommendations available")
	}
	return result, nil
}
