# ChillNetease corresponding source snapshot

Base: go-musicfox 6a7a4a5b7b14; bridge: ChillPatcher 4800dd2ac005c3c70e1bf1bc732e00f00556ec48, NativePlugins/netease_bridge. Added the five dependencies present in the official DLL build record and vendored their exact versions. Includes the source packages used by the Windows bridge, their local assets and licenses, and the full dependency metadata. Unused application UI, previews and music test fixtures are omitted.

This archive is modified for ChillNeteaseNative 1.3.0 actual listening reports. The bundled DLL is locally rebuilt from this source; it is not the unchanged upstream binary. The upstream build script copies the bridge into go-musicfox, adds cookiejar, regenerates vendor and patches the placeholder visitor NMTID to a generated value. The bridge also repairs that placeholder at runtime. This snapshot retains that runtime repair; rebuilding is API compatible but does not promise byte-identical output (compiler, Go version and generated visitor ID can differ).

Build on Windows with Go 1.24 or newer, CGO_ENABLED=1 and a compatible MinGW C compiler, using `go build -mod=vendor -buildmode=c-shared -ldflags "-s -w" -o ChillNetease.dll ./netease_bridge`. Use the source package's BuildNative.ps1 to extract and build. Third-party licenses remain in the relevant source directories.
